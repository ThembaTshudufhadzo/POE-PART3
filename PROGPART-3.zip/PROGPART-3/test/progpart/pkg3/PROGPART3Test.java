/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package progpart.pkg3;

import javax.swing.JOptionPane;
import static org.junit.Assert.assertArrayEquals;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;


public class PROGPART3Test 
{

    private List<PROGPART3.Task> tasks;

    @Before
    public void setUp() 
    {
        tasks = createSampleTasks(); // Initialize sample tasks
        PROGPART3.tasks.clear(); // Clear tasks list from previous tests
        PROGPART3.tasks.addAll(tasks); // Add tasks to PROGPART3 static list
    }

    @Test
    public void testDeveloperArrayPopulation() 
    {
        // Arrange
        PROGPART3 program = new PROGPART3();
        program.tasks.addAll(tasks); // Add tasks to the system
        program.addTask(); // Populate developer array
        // Assert
        String[] expectedDevelopers = {"Mike Smith", "Edward Harrison", "Samantha Paulson", "Glenda Oberholzer"};
        assertArrayEquals(expectedDevelopers, program.developers);
    }
    
  @Test
public void testDisplayLongestTask() 
{
  // Assuming tasks contain a task for Glenda Oberholzer with 11 hours duration
  PROGPART3 program = new PROGPART3(tasks);
  program.displayLongestTask();

  // Check for presence of key details in the output
  String output = System.out.toString();
  assertTrue(output.contains("Longest Duration"));
  assertTrue(output.contains("Glenda Oberholzer"));
}

    
    @Test
    public void testDisplayDeveloperAndDurationForLongestTask() {
        // Arrange
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        // Act
        PROGPART3.displayLongestTaskIndirectly();

        // Assert
        String expectedOutput = "Developer: Glenda Oberholzer\nDuration: 11";
        assertTrue(outContent.toString().contains(expectedOutput));
    }

    @Test
    public void testSearchTask() 
    {
        setUp();
        // Arrange
        String result = "";
        String expectedOutput = "Developer Details: Mike Smith\nTask Name: Create Login";
        assertEquals(expectedOutput,result);
    }

    @Test
    public void testSearchTasksByDeveloper() {
        // Arrange
        PROGPART3 program = new PROGPART3();
        program.tasks.addAll(tasks); // Add tasks to the system

        // Mock JOptionPane showInputDialog (ignored in this test)
        Mockito.when(JOptionPane.showInputDialog(null, "Enter Developer Name:")).thenReturn("Samantha Paulson");

        // Capture output stream to verify displayed message
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        // Act
        program.searchTasksByDeveloper();

        // Assert
        String expectedOutput = "Tasks assigned to Samantha Paulson:\n  Task Name: Create Reports\n";
        assertTrue(outContent.toString().contains(expectedOutput));
    }

    @Test
    public void testDeleteTask() {
        // Arrange
        PROGPART3 program = new PROGPART3();
        program.tasks.addAll(tasks); // Add tasks to the system

        // Mock JOptionPane showInputDialog for task name to delete
        Mockito.when(JOptionPane.showInputDialog(null, "Enter Task Name to Delete:")).thenReturn("Create Reports");

        // Act
        program.deleteTask();

        // Assert
        // Implement assertion for successful deletion based on your implementation
        // You can check if the task is no longer present in tasks list or handle output verification
        // For example:
        assertTrue(!program.tasks.stream().anyMatch(task -> task.getTaskName().equals("Create Reports")));
    }

    @Test
    public void testDisplayReport() {
        // Arrange
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        // Act
        PROGPART3.displayTaskReport();

        // Assert
        String expectedOutput = "Task Name: Create Login";
        assertTrue(outContent.toString().contains(expectedOutput));
    }

    // Helper method to create sample tasks
    private List<PROGPART3.Task> createSampleTasks() {
        List<PROGPART3.Task> tasks = new ArrayList<>();
        tasks.add(new PROGPART3.Task("Create Login", "", "Mike Smith", 5, "", "To Do"));
        tasks.add(new PROGPART3.Task("Create Add Features", "", "Edward Harrison", 8, "", "Doing"));
        tasks.add(new PROGPART3.Task("Create Reports", "", "Samantha Paulson", 2, "", "Done"));
        tasks.add(new PROGPART3.Task("Add Arrays", "", "Glenda Oberholzer", 11, "", "To Do"));
        return tasks;
    }
    
}