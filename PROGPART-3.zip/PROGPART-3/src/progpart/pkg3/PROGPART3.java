/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package progpart.pkg3;

/**
 *
 * @author lab_services_student
 */
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.stream.IntStream;
import java.util.stream.Collectors;

public class PROGPART3 {

    /**
     * @param args the command line arguments
     */

  // Method to validate the username
  public static boolean isValidUserName(String userName) 
  {
       // Check if the username is less than or equal to 5 characters
       // and contains an underscore
        return userName.length() <= 5 && userName.contains("_");
  }

  // Method to validate the password
  public static boolean isValidPassword(String password) 
  {
   boolean hasUppercase = false; // Flag to indicate if the password has an uppercase letter
        boolean hasNumber = false;   // Flag to indicate if the password has a number
        boolean hasSpecial = false;  // Flag to indicate if the password has a special character

        // Loop through each character in the password
        for (char c : password.toCharArray()) 
        {
            if (Character.isUpperCase(c)) 
            {
                hasUppercase = true;
            } else if (Character.isDigit(c)) 
            {
                hasNumber = true;
            } else if (!Character.isLetterOrDigit(c)) 
            {
                hasSpecial = true;
            }
        }

        // Check if the password is less than or equal to 8 characters
        // and has at least one uppercase letter, one number, and one special character
        return password.length() <= 8 && hasUppercase && hasNumber && hasSpecial;
  }

  // Method to validate the entered username and password against stored credentials
  public static boolean loginUser(String userName, String password, String storedUser, String storedPass) {
    return userName.equals(storedUser) && password.equals(storedPass);
  }

  // Constants for minimum username and password lengths and maximum task description length
  private static final int MIN_USER_LENGTH = 5;
  private static final int MIN_PASS_LENGTH = 8;
  private static final int MAX_TASK_DESC_LENGTH = 50;

  // Static variables
  static int taskNumber = 0; // Auto-incrementing task ID counter
  static List<Task> tasks = new ArrayList<>(); // List to store tasks

  // Arrays for task data
  static String[] developers = new String[0];
  static String[] taskNames = new String[0];
  static String[] taskIds = new String[0];
  static int[] taskDurations = new int[0];
  static String[] taskStatuses = new String[0];

  // Main method
  public static void main(String[] args) 
  {
        String userName, password;
        String firstName, lastName;
        String storedUser, storedPass;

        Scanner input = new Scanner(System.in);

        // Username input with validation
        System.out.print("Enter Username must be less than 5 characters with an underscore: ");
        userName = input.nextLine();
        while (!isValidUserName(userName)) 
        {
            System.out.println("Invalid Username. Please try again.");
            System.out.print("Enter Username: ");
            userName = input.nextLine();
        }
        System.out.println("Username successfully captured");

        // Password input with validation
        System.out.print("Enter Password must be at least 8 characters with a capital letter, number, and special character: ");
        password = input.nextLine();
        while (!isValidPassword(password)) 
        {
            System.out.println("Invalid Password. Please try again.");
            System.out.print("Enter Password: ");
            password = input.nextLine();
        }
        System.out.println("Password successfully captured");

        // User details input
        System.out.print("Enter first Name: ");
        firstName = input.nextLine();
        System.out.print("Enter Last Name: ");
        lastName = input.nextLine();

        storedUser = userName;
        storedPass = password;

        boolean logInSuccesful = false;
        while (!logInSuccesful) 
        {
            System.out.println("Log in details");
            System.out.print("Re-enter User Name: ");
            userName = input.nextLine();
            System.out.print("Re-enter password: ");
            password = input.nextLine();
            logInSuccesful = loginUser(userName, password, storedUser, storedPass);
            if (logInSuccesful) 
            {
                System.out.println("Log in successful");
                showMenu(); // Show menu after successful login
            } 
            else 
            {
                System.out.println("Log in unsuccessful. Please try again");
            }
        }
    }

    private static void displayDoneTasks() 
    {
        String message = "Tasks with Done Status:\n";

        for (Task task : tasks) {
            if (task.getTaskStatus().equals("Done")) 
            {
                message += "  Developer: " + task.getDeveloperName() + "\n";
                message += "  Task Name: " + task.getTaskName() + "\n";
                message += "  Duration: " + task.getDuration() + " hours\n\n";
            }
        }

        if (tasks.stream().noneMatch(task -> task.getTaskStatus().equals("Done"))) 
        {
            message += "  No tasks found with Done status.";
        }

        JOptionPane.showMessageDialog(null, message);
    }

    private static void displayLongestTask() 
    {
        if (tasks.isEmpty()) 
        {
            JOptionPane.showMessageDialog(null, "No tasks found.");
            return;
        }

        int maxDuration = tasks.stream().map(Task::getDuration).max(Integer::compare).orElse(0);
        List<Task> longestTasks = tasks.stream().filter(task -> task.getDuration() == maxDuration).collect(Collectors.toList());

 
        String message = "Task(s) with Longest Duration (" + maxDuration + " hours):\n";
        for (Task task : longestTasks) 
        {
            message += "  Developer: " + task.getDeveloperName() + "\n";
        }

        JOptionPane.showMessageDialog(null, message);
    }

    private static void searchTask() 
    {
        String taskName = JOptionPane.showInputDialog("Enter Task Name:");
        String developerName = JOptionPane.showInputDialog("Enter Developer Name (optional)");
        String taskStatus = JOptionPane.showInputDialog("Enter Task Status (optional)");

        boolean found = false;
        String message = "";
        for (Task task : tasks) 
        {
            if (task.getTaskName().equals(taskName) && (developerName == null || developerName.isEmpty() || task.getDeveloperName().equals(developerName)) && (taskStatus == null || taskStatus.isEmpty() || task.getTaskStatus().equals(taskStatus))) 
            {
                message += task.toString() + "\n";
                found = true;
            }
        }

        if (!found) 
        {
            message = "No task found with the specified criteria.";
        }

        JOptionPane.showMessageDialog(null, message);
    }

    private static void searchTasksByDeveloper() 
    {
        String developerName = JOptionPane.showInputDialog("Enter Developer Name:");

        String message = "Tasks assigned to " + developerName + ":\n";
        boolean found = false;
        for (Task task : tasks) 
        {
            if (task.getDeveloperName().equals(developerName)) 
            {
                message += "  Task Name: " + task.getTaskName() + "\n";
                message += "  Task Status: " + task.getTaskStatus() + "\n";
                found = true;
            }
        }

        if (!found) 
        {
            message += "  No tasks found assigned to this developer.";
        }

        JOptionPane.showMessageDialog(null, message);
    }

    private static void deleteTask() 
    {
        String taskName = JOptionPane.showInputDialog("Enter Task Name to Delete:");
        int indexToDelete = -1;

        for (int i = 0; i < tasks.size(); i++) 
        {
            if (tasks.get(i).getTaskName().equals(taskName)) 
            {
                indexToDelete = i;
                break;
            }
        }

        if (indexToDelete != -1) 
        {
            tasks.remove(indexToDelete);

            // Update arrays to reflect task deletion (assuming separate arrays)
               developers = new String[tasks.size()];
            taskNames = new String[tasks.size()];
            taskDurations = new int[tasks.size()];
            taskStatuses = new String[tasks.size()];

            for (int i = 0; i < tasks.size(); i++) {
                developers[i] = tasks.get(i).getDeveloperName();
                taskNames[i] = tasks.get(i).getTaskName();
                taskDurations[i] = tasks.get(i).getDuration();
                taskStatuses[i] = tasks.get(i).getTaskStatus();
            }

            JOptionPane.showMessageDialog(null, "Task deleted successfully.");
        } 
        else 
        {
            JOptionPane.showMessageDialog(null, "Task not found.");
        }
    }

    private static void displayTaskReport() 
    {
        if (tasks.isEmpty()) 
        {
            JOptionPane.showMessageDialog(null, "No tasks found.");
            return;
        }

        String message = "Task Report:\n\n";
        for (Task task : tasks) 
        {
            // Add task details to the message string
            message += "  Task ID: " + task.getTaskId() + "\n";
            message += "  Developer: " + task.getDeveloperName() + "\n";
            message += "  Task Name: " + task.getTaskName() + "\n";
            message += "  Duration: " + task.getDuration() + " hours\n";
            message += "  Status: " + task.getTaskStatus() + "\n\n";
        }

        JOptionPane.showMessageDialog(null, message, "Task Report", JOptionPane.INFORMATION_MESSAGE);
    }

    // Method to display the main menu
    private static void showMenu() 
    {
        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");
        while (true) 
        {
            int choice = Integer.parseInt(JOptionPane.showInputDialog(null, "Choose an option:\n1. Add Task\n2. Show Report\n3. Display Done Tasks\n4. Display Longest Task\n5. Search Task\n6. Search Tasks by Developer\n7. Delete Task\n8. Quit"));
            switch (choice) 
            {
                case 1:
                    addTask();
                    break;
                case 2:
                    displayTaskReport();
                    break;
                case 3:
                    displayDoneTasks();
                    break;
                case 4:
                    displayLongestTask();
                    break;
                case 5:
                    searchTask();
                    break;
                case 6:
                    searchTasksByDeveloper();
                    break;
                case 7:
                    deleteTask();
                    break;
                case 8:
                    JOptionPane.showMessageDialog(null, "Exiting program");
                    return;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Please try again.");
            }
        }
    }

    // Method to add a new task
    public static void addTask() 
    {
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the number of tasks you want to add:"));
        int currentSize = developers.length;

        // Check if arrays need expansion
        if (currentSize < numTasks + tasks.size()) 
        {
            developers = Arrays.copyOf(developers, currentSize + numTasks);
            taskNames = Arrays.copyOf(taskNames, currentSize + numTasks);
            taskIds = Arrays.copyOf(taskIds, currentSize + numTasks);
            taskDurations = Arrays.copyOf(taskDurations, currentSize + numTasks);
            taskStatuses = Arrays.copyOf(taskStatuses, currentSize + numTasks);
        }

        for (int i = 0; i < numTasks; i++) 
        {
            taskNumber = (i + 1);
            String taskName = JOptionPane.showInputDialog(null, "Enter Task Name:");
            String taskDescription = JOptionPane.showInputDialog(null, "Enter Task Description (max 50 characters):");
            while (!checkTaskDescription(taskDescription)) 
            {
                taskDescription = JOptionPane.showInputDialog(null, "Task description too long. Please enter less than 50 characters:");
            }
            String developerName = JOptionPane.showInputDialog(null, "Enter Developer Name (First and Last):");
            int taskDuration = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter Task Duration (hours):"));
            String taskId = createTaskID(taskName, developerName);
            String taskStatus = (String) JOptionPane.showInputDialog(null, "Select Task Status:", "Choose Task Status", JOptionPane.QUESTION_MESSAGE, null, new String[]{"To Do", "Doing", "Done"}, "To Do");

            tasks.add(new Task(taskName, taskDescription, developerName, taskDuration, taskId, taskStatus));

            developers[tasks.size() - 1] = developerName;
            taskNames[tasks.size() - 1] = taskName;
            taskIds[tasks.size() - 1] = taskId;
            taskDurations[tasks.size() - 1] = taskDuration;
            taskStatuses[tasks.size() - 1] = taskStatus;

            JOptionPane.showMessageDialog(null, "Task successfully added!");
        }
        printTaskDetails(); // Optional: Print using separate arrays
        int totalHours = returnTotalHours();
        JOptionPane.showMessageDialog(null, "Total estimated hours: " + totalHours);
    }

    // Method to check if the task description is within the maximum length limit
    public static boolean checkTaskDescription(String taskDescription) 
    {
        return taskDescription.length() <= 50;
    }

    public static String createTaskID(String taskName, String developerName) 
    {
  String firstTwoLetters = taskName.substring(0, 2).toUpperCase();

  // Extract the last three letters of the developer's last name
  int developerNameLength = developerName.length();
  int indexOfSpace = developerName.lastIndexOf(' '); // Find the last space
  String lastName;
  
  if (indexOfSpace != -1) 
  {
    lastName = developerName.substring(indexOfSpace + 1); // Extract last name after space
  } 
  else 
  {
    lastName = developerName; // If no space, use the entire developer name
  }

  String lastThreeLetters = lastName.length() >= 3 ? lastName.substring(lastName.length() - 3).toUpperCase() : lastName.toUpperCase();

  return firstTwoLetters + ":" + taskNumber++ + ":" + lastThreeLetters;
}
    // Method to generate a unique task ID based on task name and developer name
    //public static String createTaskID(String taskName, String developerName) 
   // {
   //     String firstTwoLetters = taskName.substring(0, 2).toUpperCase();
   //     String lastThreeLetters = developerName.split(" ")[1].substring(0, 3).toUpperCase();
   //     return firstTwoLetters + ":" + taskNumber++ + ":" + lastThreeLetters;
  //  }

    // Method to print the details of all tasks
    private static void printTaskDetails() 
    {
        String message = "";
        for (Task task : tasks) 
        {
            message += task.toString() + "\n";
        }
        JOptionPane.showMessageDialog(null, message);
    }

    // Method to calculate and return the total estimated hours for all tasks
    private static int returnTotalHours() 
    {
        int totalHours = 0;
        for (Task task : tasks) 
        {
            totalHours += task.getDuration();
        }
        return totalHours;
    }

    // Class representing a task
    public static class Task 
    {
        int taskNumber;
        String taskName;
        String taskDescription;
        String developerName;
        int duration;
        String taskId;
        String taskStatus;
       

        public Task(String taskName, String taskDescription, String developerName, int duration, String taskId, String taskStatus) 
        {
            this.taskNumber = taskNumber;
            this.taskName = taskName;
            this.taskDescription = taskDescription;
            this.developerName = developerName;
            this.duration = duration;
            this.taskId = taskId;
            this.taskStatus = taskStatus;
        }
        // Override toString() method to display task details
        public String toString() 
        {
            return "Task Status: " + taskStatus + "\n" +
                    "Developer Details: " + developerName + "\n" +
                    "Task Number: " + taskNumber + "\n" +
                    "Task Name: " + taskName + "\n" +
                    "Task Description: " + taskDescription + "\n" +
                    "Task ID: " + taskId.toUpperCase() + "\n" +
                    "Duration: " + duration + " hours";
        }

        public static void displayLongestTaskIndirectly() 
        {
          displayLongestTask();
        }
        
        public int getDuration() 
        {
            return duration;
        }

        public String getTaskStatus() 
        {
            return taskStatus;
        }

        public String getDeveloperName() 
        {
            return developerName;
        }

        public String getTaskName() 
        {
            return taskName;
        }

        public String getTaskId() 
        {
            return taskId;
        }
    }
}